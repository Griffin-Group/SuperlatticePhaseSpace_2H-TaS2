#!/bin/bash
#SBATCH --job-name=cvgckblkz
#SBATCH --partition=dirac1
#SBATCH --account=dirac1
#SBATCH --qos=normal
#SBATCH --exclusive=user
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=24
#SBATCH --time=2:00:00

module unload intel/2016.4.072
module load intel/2018.5.274.par
module load vasp_intelmpi/5.4.4.16052018

EXE="vasp_std"
time mpirun $EXE
exit 0

